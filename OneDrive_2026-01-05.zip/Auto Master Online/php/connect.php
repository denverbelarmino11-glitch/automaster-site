<?php

$con = mysqli_connect("localhost","root","","amo") or die ("Connection Error");


// UPDATE your_table_name
// SET Stock = Stock - 1
// WHERE <your_condition>;


// UPDATE your_table_name
// SET Stock = Stock + 1
// WHERE <your_condition>;



?>


<!-- 

Things to do

signup.html

login.html


Databases needed to connect here

User Login Connection(login.html)
Product Home Page Connection
Order Cart Connection
Item Stock Connection
Sales Analytics Connection (No Idea how to do)


variables (for login and signup)
ID (From Database)
Username
PasswordE
EmailE
pNumber


Cart_ID PK


$Items = Quantity_Of_All_Items

$Total = Total_Price_Of_All_Items


You have purchased
Items....

Item : $Items
Shipping : PHP Fixed Amount
Subtotal : PHP 
Total : PHP echo $Total









 -->


 <!-- asdasd -->


 for cart.php (backup)
 <?php
  if(isset($_POST['submit'])){

  $result = mysqli_query($con, "SELECT * FROM cartTable");

      $ID_Cart = $_POST['Cart_ID'];
      $Total_Quantity = $_POST['Quantity_Of_All_Items'];
      $totalPrice_Items = $_POST['totalPrice_Of_All_Items'];
    

    // order

    mysqli_query($con, "INSERT INTO cartTable(Cart_ID,Quantity_Of_All_Items,totalPrice_Of_All_Items) VALUES('$ID_Cart','$Total_Quantity','$totalPrice_Items')") or die ("Error Occured");

      echo "<div class = 'message'>
              <p> Added to Cart</p>
              </div> <br>";

   

  }


?>


backup
<?php
session_start();
include("connect.php");

$totalQuantity = 0; // Initialize total quantity
$totalPrice = 0;    // Initialize total price

// Fetch current stock value from the database
if(isset($_POST['submit'])) { // Submit button clicked
    // Fetch all stocks from the database
    $result = mysqli_query($con, "SELECT * FROM stock");
    $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);

    foreach($stocks as $stock) {
        $stockId = $stock['Product_ID'];
        $stockChange = intval($_POST['stockMinusPlus_'.$stockId]);

        // Get the current stock
        $currentStock = $stock['Stock'];

        // Calculate the new stock after the change
        $newStock = $currentStock - $stockChange;

        // Update the stock quantity if it's valid (non-negative)
        if ($newStock >= 0) {
            // Update the stock quantity
            mysqli_query($con, "UPDATE stock SET Stock = $newStock WHERE Product_ID = $stockId") or die ("Error Occurred");
        } else {
            // Handle negative stock quantity (if needed)
            // You may want to add error handling here
            echo "Error: Negative stock quantity detected for item with ID $stockId";
        }

        // Calculate total quantity and total price
        $totalQuantity += $stockChange;                            // Increment total quantity by the stock change
        $totalPrice += $stockChange * $stock['Price']; // Increment total price by the product of stock change and price
    }

    // Display success message
    echo "<div class='message'>
            <p>Stock Quantity Updated Successfully</p>
          </div><br>";
    echo "<a href='javascript:window.location.reload()'><button class='btn'>Go Back</button></a>";
}

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>

    <link rel="stylesheet" href="/css/styles-cart.css">
    <link rel="icon" href="/images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">


    <!-- Jscript - so number input won't reach negative value-->
    <script>
        // JavaScript function to prevent entering negative values in the quantity input
        function preventNegativeValue(event) {
            if (event.target.value < 0) {
                event.target.value = 0; // Set the value to 0 if it's negative
            }
        }
    </script>


  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->
    <!-- Top part of the page -->
    <div class="grid1">
        <img src="/images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Cart</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
          <p class="others" onclick="location.href = '/html/main-customer.html';">Home</p>
          <p class="others" onclick="location.href = '/html/customer-support.html';">Customer Support</p>
          <p class="others" onclick="location.href = '/html/social-media.html';">Social Media</p>
          <p class="others" onclick="location.href = '/html/about-us.html';">About Us</p>
          <p class="others" onclick="location.href = '/html/cart.html';">Cart</p>
        </div>
        <img src="/images/profile.jpg" alt="profile icon" style="float: left;">
        <p>Arvin Garcia</p>
        <select id="profile-dropdown" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
          <option value=""></option>
          <option value="logout">Logout</option>
        </select>
    </div>
    <!-- end -->
    <div class="grid2">
      <div style="display: flex; margin-top: -20px;">
        <h1>Product</h1>
        <div style="margin: 0 auto;">
          <h1>Quantity</h1>
        </div>
        <div style="margin-left: auto;">
          <h1 >Subtotal</h1>
        </div>
      </div>
      <hr>
      <div class="vertical-media-scroller">

      <form action="" method="post">
        <?php foreach($stocks as $stock): ?>
            <p><?php echo $stock['PName']; ?></p>
            <p> Current Stock: <span id="currentStockDisplay_<?php echo $stock['Product_ID']; ?>"><?php echo $stock['Stock']; ?></span> </p>
            <p>PHP: <?php echo $stock['Price']; ?></p>
            <p>Subtotal: PHP <?php echo $stock['Price']; ?></p>
            <p> Quantity: </p>
            <input type="number" name="stockMinusPlus_<?php echo $stock['Product_ID']; ?>" id="stockMinusPlus_<?php echo $stock['Product_ID']; ?>" oninput="preventNegativeValue(event)">
        <?php endforeach; ?>
        <br>
        <br>
        <input type="submit" class="btn" name="submit" value="Order">
    </form>
 
        </div>
    </div>

    <!--  Order Summary-->

    <div class="grid3">
      <h1 style="text-align: center; margin-top: 1px;">Order Summary</h1>
      <hr>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">ITEMS</p>
        <p style="font-weight: 400; margin-left: 165px; font-size: 15px;"><?php echo $totalQuantity; ?></p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">SHIPPING</p>
        <p style="font-weight: 400; margin-left: 140px; font-size: 15px;">PHP 15500.00 Fixed nalang??</p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">SUBTOTAL</p>
        <p style="font-weight: 400; margin-left: 131px; font-size: 15px;">PHP <?php echo $totalPrice; ?></p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">TOTAL</p>
        <p style="font-weight: 400; margin-left: 165px; font-size: 15px;">PHP <?php echo $totalPrice; ?></p>
      </div>
      <hr>
      <div class="center-wrapper">
        <button class="btn-purchase">Purchase</button>
      </div>
    </div>
  </div>

    <!-- Functionalities -->
    <script src="/javascript/script-main-customer.js"></script>
    <script src="/javascript/script-quantity.js"></script>
</body>

</html>
