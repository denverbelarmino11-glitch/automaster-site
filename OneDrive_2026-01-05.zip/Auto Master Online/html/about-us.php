<?php 
    session_start();

    include("connect.php");
     
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <link rel="stylesheet" href="../css/styles-about-us.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->
    <!-- Top part of the page -->
    <div class="grid1">
        <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Auto Master Online</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
        </div>
        <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
        <p><?php echo $res_Uname ?></p>

        <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>
    <!-- end -->
    <div class="grid2">
      <div class="container-text">
        <h1>About Us</h1>
          <p>At Auto Master Online, we're dedicated to providing a seamless shopping experience, offering a wide range of top-notch products that enhance both the functionality and aesthetics of your vehicle. Each product in our inventory undergoes thorough quality control checks, giving you peace of mind knowing you're investing in top-tier accessories.</p>
      </div>
      <div class="container-text">
        <h1>Our Vision</h1>
          <p>We strive to be the ultimate destination for car enthusiasts, providing a diverse range of high-quality accessories to effortlessly customize and enhance their vehicles. Our vision is to create a user-friendly platform where drivers can find everything they need to elevate their driving experience, from stylish interior upgrades to performance-enhancing additions.</p>
      </div>
      <div class="container-text">
        <h1>Our Mission</h1>
          <p>Our mission is to make finding the perfect car accessories effortless. We aim to offer a comprehensive selection of products that cater to the diverse needs and preferences of car enthusiasts. With our user-friendly website and exceptional customer service, we strive to exceed your expectations every step of the way.</p>
      </div>
    </div>
  </div>

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>
</body>

</html>
