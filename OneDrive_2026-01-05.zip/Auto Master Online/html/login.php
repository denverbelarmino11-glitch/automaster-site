<?php 
    session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Master Online</title>
    <link rel="icon" href="../images/logo.jpg">

    <link rel="stylesheet" href="../css/styles-login.css">
	<link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Barlow and Inter) -->
	<link href='https://fonts.googleapis.com/css?family=Barlow' rel='stylesheet'>
	
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>





<body>
  <div class="wrapper"> <!-- Wraps the whole page -->

  <!-- php -->
  <?php
    include("connect.php");

    if (isset($_POST['submit'])){
      $username = mysqli_real_escape_string($con,$_POST['Username']);
      $password = mysqli_real_escape_string($con,$_POST['Password']);

      $result = mysqli_query($con, "SELECT * FROM users WHERE USERNAME = '$username' AND PASSWORD = '$password'") or die("Select Error");
      $row = mysqli_fetch_assoc($result);

     if(mysqli_num_rows($result) > 0){
      if($row['USERNAME'] == $username && $row['PASSWORD'] == $password ){
        echo "logged in";
        $_SESSION["Username"] = $row["USERNAME"];
        $_SESSION["id"] = $row["USER_ID"];

        $checkmanager = mysqli_query($con, "SELECT * FROM users WHERE USERNAME = '$username' AND PASSWORD = '$password' AND status LIKE 'manager'") or die("Select Error");
        if (mysqli_num_rows($checkmanager) == 1){
          header("Location: main-manager.php");
        }else{
          header("Location: main-customer.php");

        }
       
      }


      }else{
        
        echo "<script> alert('Wrong Password or Username!')</script>";
        
        
      }
      


  }else{

    
  }
    
  
  ?>

    <!-- Top part of the page -->
    <div class="grid1">
      <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
      <p>Auto Master Online</p>
      <input type="text" class="search-bar" placeholder="Search">
      <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = '../html/customer-support.html';">Customer Support</p>
        <p class="others" onclick="location.href = '../html/social-media.html';">Social Media</p>
        <p class="others" onclick="location.href = '../html/about-us.html';">About Us</p>
      </div>
    </div>
    <!-- end -->
	
	<!-- Login Page Start -->
	<div class="grid2">
		<img src="../images/logonobg2.png" class="login-logo" alt="AMO logo" style="float: center;">
		<center>
		<form class="login-form" action="" method="post">
			<!--
      <input type="text" class="login-input" placeholder="Email">
      <input type="password" class="login-input" placeholder="Password" style="margin-bottom: 2px;">
      -->
      <div class="field input">
      <input type="text" class="login-input" placeholder="Username" name="Username" id="Username" required>
      </div>
      
      <div class="field input">
      <input type="password" class="login-input" placeholder="Password" style="margin-bottom: 2px;" name="Password" id="Password" required>
      </div>
			</center>
    
    <p class="sameline" style="margin-right: 142px;">Don't have an account?</p> 
		<p class="sameline underline" onclick="location.href = 'signup.php';">Sign Up</p>
		<br>

		<!--<a href="/html/main-customer.html"><button class="login-button" style="margin-top: 25px; margin-bottom: 5px;">Log In</button></a> 
    -->

    <div class="field input">
    <input type="submit" class="btn" name="submit" value="Login" required> 
    </div>
      

    <br>
    <p class="sameline" style="margin-right: 76px;">Just want to browse products?</p> 
		<p class="sameline underline" onclick="location.href = 'main-customer-guest.php';">View as guest</p>
		<br>
		<br>
    </div>
    </form>
	<!-- end -->

  </div> <!-- end of wrapper div -->

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>

    

</body>

</html>
