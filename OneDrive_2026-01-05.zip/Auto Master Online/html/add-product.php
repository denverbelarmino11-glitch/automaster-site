<?php
	session_start();

	include("connect.php");
	
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Auto Master Online</title>
		<!-- Fonts used -->
		<link rel="stylesheet" href="../css/styles-add-product.css">
		<link rel="icon" href="../images/logo.jpg">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
		
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

</head>
<body>
	<!-- PHP portion -->
  <?php 
	//For profile name change
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    
    $res_ID = $result['USER_ID'];
  }


  // for adding product
  if(isset($_POST['submit'])){
	
	$fileName = $_FILES["image"]["name"]; 
	$tempname = $_FILES["image"]["tmp_name"];
	$folder = '../images/' .$fileName;
	

	$prodName = $_POST['NAME'];
	$prodPrice = $_POST['PRICE'];
	$prodStock = $_POST['STOCK'];
	$prodDescriptionE = $_POST['Description'];
	$prodCategoryE = $_POST['Category'];
	
	

	mysqli_query($con, "INSERT INTO product(NAME,PRICE,STOCK,Description,Category,image) VALUES('$prodName','$prodPrice','$prodStock','$prodDescriptionE','$prodCategoryE','$fileName')") or die ("Error Occured");



	echo "<script> alert('The Product has been succesfully added!')</script>";
	header("Refresh:0");

  }else{
  

  
  
  ?>



    <div class="wrapper">
			<div class="grid1">
				<img src="../images/profile.jpg	" alt="profile icon" style="float: left;">
				<p class="profile-name">
					<br>
				<p><?php echo $res_Uname ?></p>
					<span class="small-text">Manager</span>
				</p>
				
				<select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
		<option value="Logout"> <a href="logout.php">Log Out</a></option>
      </select>
			</div>

			<div class="grid2">
				<div class="sidebar">
					<div class="logo-container" style="margin-bottom: -30px;">
							<img src="../images/logo2.jpg" alt="Logo" style="width: 80px; margin-bottom: 6px;">
					</div>
					<ul>
							<li><a href="main-manager.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
							<li><a href="item-stock.php"><i class="fas fa-box-open"></i>Item Stock</a></li>
							<li><a href="add-product.php"><i class="fas fa-box-open"></i>Add Product</a></li>
					</ul>
				</div>
			</div>
	</div>
		<!-- Start of Grid 3 -->

		<form action = "" method="post" enctype="multipart/form-data">
		<div class="grid3">
			<div style="display: flex;">
				<h1>Add Product</h1>
				<!--
				<button style="margin-left: auto; height: 30px; margin-right: 21px; margin-top: 22px;">Submit</button>
  				-->

				<!-- Submit Button -->
				<div class="field input"> 
        
				<input type="submit" class="btn" name = "submit" value="Submit">
  
				</div>
	  
		</div>

			
				<div class="grid4" style="background-color: #EBEBEB;">
					<p>Product Image</p>
						<div class="imgbox">
						<img id="blah" src="/images/white.png" alt="image preview" />
						</div>
						<input type="file" id="image" name="image" accept=".jpg, .jpeg, .png" value="" />
						<label for="imgInp">Add Image</label>
				</div>
			
				<div class="grid5" style="background-color: #EBEBEB;">
					<p>Product Name</p>
					<input type="text" class="product-name" placeholder="Add Product Name" name ="NAME" id = "NAME" autocomplete = "off" required>
					<p>Product Description</p>
					<input type="text" class="product-description" placeholder="Add Product Description" name ="Description" id = "prodDescription" autocomplete = "off" required >
				</div>
			
				<div class="grid6" style="background-color: #EBEBEB;">
					<p>Product Category</p>
					<select class="product-category" style="border-radius: 6px; padding-left: 2px;" name ="Category" id = "prodCategory" autocomplete = "off" required>
						<option value="">Choose Category...</option>
						<optgroup label="Interior">
						  <option value="floor_mats">Floor Mats</option>
						  <option value="seat_covers">Seat Covers</option>
						  <option value="sunshades">Sunshades</option>
						  <option value="organizers">Organizers</option>
						  <option value="phone_mounts">Phone Mounts</option>
						</optgroup>
						<optgroup label="Exterior">
						  <option value="car_covers">Car Covers</option>
						  <option value="windshield_sunshades">Windshield Sunshades</option>
						  <option value="mud_flaps">Mud Flaps</option>
						  <option value="roof_racks">Roof Racks</option>
						  <option value="bike_racks">Bike Racks</option>
						</optgroup>
						<optgroup label="Performance">
						  <option value="air_suspension_kit">Air Suspension Kit</option>
						  <option value="coil_spring">Coil Spring</option>
						  <option value="polyurethane_bushing">Polyurethane Bushing</option>
						  <option value="wheel_spacer">Wheel Spacer</option>
						  <option value="sway_bar">Sway Bar</option>
						</optgroup>
						<optgroup label="Safety">
						  <option value="dash_cam">Dash Cam</option>
						  <option value="car_alarm">Car Alarm</option>
						  <option value="side_mirror">Side Mirror</option>
						  <option value="parking_sensor">Parking Sensor</option>
						  <option value="wheel_lock">Wheel Lock</option>
						</optgroup>
						<optgroup label="Cleaning and Maintenance">
						  <option value="air_purifier">Air Purifier</option>
						  <option value="car_vacuum">Car Vacuum</option>
						  <option value="engine_oil">Engine Oil</option>
						  <option value="air_filter">Air Filter</option>
						  <option value="pressure_washer">Pressure Washer</option>
						</optgroup>
						<optgroup label="Miscellaneous">
						  <option value="keychain">Keychain</option>
						  <option value="phone_charger">Phone Charger</option>
						  <option value="cup_holder">Cup Holder</option>
						  <option value="car_fragrance">Car Fragrances</option>
						  <option value="travel_pillow">Travel Pillow</option>
						</optgroup>
					</select>
					<br><br>
					<!-- <p>Price Range</p>
					<select class="product-category" style="border-radius: 6px; padding-left: 2px;" name ="priceRange" id = "priceRange" autocomplete = "off" required>
						<option value="">Choose Price Range...</option>
						<option value="air_purifier">PHP 0 - PHP 5,000</option>
						<option value="car_vacuum">PHP 5,000 - PHP 10,000</option>
						<option value="engine_oil">PHP 10,000 - PHP 15,000</option>
						<option value="air_filter">PHP 15,000 - PHP 20,000</option>
						<option value="pressure_washer">PHP 20,000+</option>
					</select> -->
					<br><br>
				</div>
			
				<div class="grid7" style="background-color: #EBEBEB;">
					<p>Price</p>
					<input type="text" class="product-details" placeholder="₱ Add Price" name ="PRICE" id = "PRICE" autocomplete = "off" required>
					<br><br>
					<p>Available Stock</p>
					<input type="text" class="product-details" placeholder="Add Current Stock" name ="STOCK" id = "STOCK" autocomplete = "off" required >
				</div>
		</div>
		
</div>
</form>
		
    </div>

    <script src="../javascript/script-main-manager.js"></script>

	<?php } ?>

</body>
	

</html>
