<?php
session_start();
include("connect.php");

$ID = $_SESSION['id'];
$query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

while($result = mysqli_fetch_assoc($query)){
  $res_Uname = $result['USERNAME'];
 
  $res_ID = $result['USER_ID'];
}


// Initialize total quantity and total price



// Fetch current stock value from the database
if(isset($_POST['submit'])) { // Submit button clicked
  // Fetch all stocks from the database
  $result = mysqli_query($con, "SELECT * FROM cart WHERE USER_ID = $res_ID");
  $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);

  // Initialize total quantity and total price
  $totalQuantity = 0;
  $totalPrice = 0;
  $totalItems = 0;

  foreach ($stocks as $stock){
    $productID = $stock['PRODUCT_ID']; 
    $result1 = mysqli_query($con, "SELECT * FROM product WHERE PRODUCT_ID = '$productID'");
    $row = mysqli_fetch_assoc($result1);

    $totalItems = $totalItems + 1;
   


    $rprice = $row['NAME'];
    


  }
  

  // Display success message
  echo "<div class='message'>
          <p>Stock Quantity Updated Successfully</p>
        </div><br>";
  echo "<a href='javascript:window.location.reload()'><button class='btn'>Go Back</button></a>";
}


?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>

    <link rel="stylesheet" href="../css/styles-cart.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">


    <!-- Jscript - so number input won't reach negative value-->
    <script>
        // JavaScript function to prevent entering negative values in the quantity input
        function preventNegativeValue(event) {
            if (event.target.value < 0) {
                event.target.value = 0; // Set the value to 0 if it's negative
            }
        }
    </script>


  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->
    <!-- Top part of the page -->
    <div class="grid1">
        <img src="/images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Cart</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
        </div>
        <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
        <p><?php echo $res_Uname ?></p>
        <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>
    <!-- end -->
    <div class="grid2">
      <div style="display: flex; margin-top: -20px;">
        <h1>Product</h1>
        <div style="margin: 0 auto;">
          <h1>Quantity</h1>
        </div>
        <div style="margin-left: auto;">
          <h1 >Subtotal</h1>
        </div>
      </div>
      <hr>
      <div class="vertical-media-scroller">

      <?php 
          // Fetch all stocks from the database
         $result = mysqli_query($con, "SELECT * FROM cart WHERE USER_ID = $res_ID");
         $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);
          ?>
            <form action="" method="post">
          <?php
        // Initialize total quantity and total price
        $totalQuantity = 0;
         $totalPrice = 0;
         $subtotal = 0;
         $totalItems = 0;
         $Shipping = 100;
        
           foreach($stocks as $stock): ?>

    
        
          <?php
              $productID = $stock['PRODUCT_ID']; 
              $result1 = mysqli_query($con, "SELECT * FROM product WHERE PRODUCT_ID = '$productID'");
              $row = mysqli_fetch_assoc($result1);

              $price = $stock['quantity'] * $row['PRICE'];
              $subtotal = $subtotal + $price;
              $totalItems = $totalItems + 1;

              $totalPrice = $subtotal + $Shipping;
             
             
              ?>
              <div class="media-item" >
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                  <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-disc"><p>Quantity           <?php echo $stock["quantity"]  ?></p></div>
                      <div class="price-disc"> <p> Add/Decrease Stock: </p></div>
                     <input type="number" name="stockMinusPlus_.<?php echo $stock['PRODUCT_ID']; ?>" id="stockMinusPlus_<?php echo $stock['PRODUCT_ID']; ?>">
                     
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
                  
        ?>
        
        <br>
        <br>
        <input type="submit" class="btn" name="submit" value="Add to Cart">
        </form>
        <?php endforeach; ?>
 
        </div>
    </div>

    <!--  Order Summary-->
    <form action="" method="post">
    <div class="grid3">
      <h1 style="text-align: center; margin-top: 1px;">Order Summary</h1>
      <hr>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">ITEMS</p>
        <p style="font-weight: 400; margin-left: 165px; font-size: 15px;"><?php echo $totalItems; ?></p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">SHIPPING</p>
        <p style="font-weight: 400; margin-left: 140px; font-size: 15px;">PHP 100</p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">SUBTOTAL</p>
        <p style="font-weight: 400; margin-left: 131px; font-size: 15px;">PHP <?php echo $subtotal; ?></p>
      </div>
      <div style="display: flex;">
        <p style="font-weight: 700; font-size: 15px;">TOTAL</p>
        <p style="font-weight: 400; margin-left: 165px; font-size: 15px;">PHP <?php echo $totalPrice; ?></p>
      </div>
      <hr>
      <div class="center-wrapper">
      
      <input type="submit" class="btn" name="purchase" value="Purchase">
       
      </div>
    </div>
    </form>
  </div>
  

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>
    <script src="../javascript/script-quantity.js"></script>
</body>

</html>
