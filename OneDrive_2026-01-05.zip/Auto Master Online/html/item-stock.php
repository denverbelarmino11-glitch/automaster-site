<!-- ADMIN SIDE -->


<?php
session_start();


include("connect.php");


//fetch current stock value from the database
if(isset($_POST['submit'])){ //submit button
  // Fetch all stocks from the database
  
  $result = mysqli_query($con, "SELECT * FROM product");
  $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);




  foreach($stocks as $stock) {
      
      /*
      if ($stockChange != NULL) {
          // Update the stock quantity
          mysqli_query($con, "UPDATE product SET STOCK = $newStock WHERE PRODUCT_ID = $stockId") or die ("Error Occurred");
      } else {
          // Handle negative stock quantity (if needed)
          // You may want to add error handling here
          echo "Error: Negative stock quantity detected for item with ID $stockId";
      }
      */
  }

  //end session
  // session_unset();
  //session_destroy();

     // After updating the database, fetch the updated stocks again
     $result = mysqli_query($con, "SELECT * FROM product");
     $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);
 
     // Display success message
     echo "<div class='message'>
             <p>Stock Quantity Updated Successfully</p>
           </div><br>";
     echo "<a href='javascript:window.location.reload()'><button class='btn'>Go Back</button></a>";
 } else {
     // Fetch stocks from the database if the form is not submitted yet
     $result = mysqli_query($con, "SELECT * FROM product");
     $stocks = mysqli_fetch_all($result, MYSQLI_ASSOC);
 }

?>





<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Item Stock</title>
		<!-- Fonts used -->
    <link rel="icon" href="../images/logo.jpg">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">

		<link rel="stylesheet" href="../css/styles-item-stock-v2.css">
		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


	
</head>
<body>
    <div class="wrapper">
        <div class="grid1">
          <img src="../images/profile.jpg	" alt="profile icon" style="float: left;">
          <p class="profile-name">
          <p>Admin</p>
            <span class="small-text">Manager</span>
          </p>
          
          <select id="profile-dropdown" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        <option value="Logout"> <a href="logout.php">Log Out</a></option>
      </select>
        </div>

    <div class="grid2">
      <div class="sidebar">
          <div class="logo-container" style="margin-bottom: -30px;">
              <img src="../images/logo2.jpg" alt="Logo" style="width: 80px; margin-bottom: 6px;">
          </div>
          <ul>
              <li><a href="main-manager.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
							<li><a href="item-stock.php"><i class="fas fa-box-open"></i>Item Stock</a></li>
							<li><a href="add-product.php"><i class="fas fa-box-open"></i>Add Product</a></li>
          </ul>
      </div>
  </div>
		
    <div class="grid3">
      <div class="topmost">
        <h3>Item Stock</h3>
        
        <!-- <button class="button-add-product"><a href="/html/add-product.html" style="color: white; text-decoration:none;">Add Product</a></button> -->
      </div>
      <div>
        <div class="vertical-media-scroller">

         <!-- <div class="media-item"> Entire product container
            <div class="item-gray-bg">
              <div class="item-white-bg">
                <img src="/item-images/spoiler-ducktail.webp" alt="cart icon" style="width: 120px; margin-top: 10px;">
              </div>
              <div class="item-details">
                <h5>Spoiler Ducktail</h5>
                <p class="sold">1,064 sold</p>
                <div class="quantity-container">
                  <div class="quantity-amount">
                    <button class="button-quantity">27</button>
                  </div>
                  <div class="quantity-changer">
                    <div class="quantity">
                      <span class="minus">-</span>
                      <span class="count">1</span>
                      <span class="plus">+ </span>
                    </div>
                  </div>
                    <button class="button-add">Add</button>
                </div>
              </div>
            </div>
          </div> end  -->
          
           
            
    <?php foreach($stocks as $stock): 
      error_reporting(E_ALL ^ E_WARNING);
      $stockId = $stock['PRODUCT_ID'];

      // Get the current stock
      $currentStock = $stock['STOCK'];
      if(isset($_POST['submit'])){
        $stockId = $_POST['prod_id'];
        $currentStock = $_POST['stocking'];
        $stockChange = $_POST['stockMinusPlus'];
        // Calculate the new stock after the change
        $newStock = $currentStock + $stockChange;
        
        

        // Update the stock quantity if it's valid (non-negative)
          mysqli_query($con, "UPDATE product SET STOCK = $newStock WHERE PRODUCT_ID = $stockId") or die ("Error Occurred");

          $SStock = $_POST['stockMinusPlus'];
          session_unset();
          session_destroy();
        }
      ?>
      <form action="" method="post">

      <p> currentStockDisplay_<?php echo $stock['PRODUCT_ID']; ?> </p>
        <p><?php echo $stock['NAME']; ?></p>
        <p> Current Stock: <span id="currentStockDisplay_<?php echo $stock['PRODUCT_ID']; ?>"><?php echo $stock['STOCK']; ?></span> </p>
        <p> Add/Decrease Stock: </p>
        <input type="hidden" value=<?php echo $stock['PRODUCT_ID']; ?> name="prod_id">
        <input type="hidden" value=<?php echo $stock['STOCK']; ?> name="stocking">
        <input type="number" name="stockMinusPlus" id="stockMinusPlus">
    
    <br>
    <br>
    <input type="submit" class="btn" name="submit" value="Add Product">
  </form>
  <?php endforeach; ?>


          </div>
      </div>
		</div>
		

    </div>

    <script src="../javascript/script-main-manager.js"></script>
    <script src="../javascript/script-quantity.js"></script>

</body>
	

</html>
