<?php
  session_start();

  include("connect.php");
  

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <link rel="stylesheet" href="../css/styles-customer.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->

  <!-- PHP Portion -->
  <?php 
  
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  $sql = "SELECT * FROM product";
  $all_product = mysqli_query($con, $sql);
  $all_product_again = mysqli_query($con, $sql);

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }
  
  

  
  
  ?>

    <!-- Top part of the page -->
    <div class="grid1">
      <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
      <p>Auto Master Online</p>
      <input class="search-bar" placeholder="Search" list="products" id="search-bar" onkeydown = "
      if (event.keyCode == 13) {
        var selectedTitle = document.getElementById('search-bar').value;
        var value2send = document.querySelector(`#products option[value='${this.value}']`).dataset.value; // Here now you have the book title id.
 				window.location='../html/product2.php?prodid='+value2send;
      }">

      <datalist id="products" role="listbox">
        <?php
          while($row = mysqli_fetch_assoc($all_product_again)){
                ?>
              <option data-value='<?php echo $row["PRODUCT_ID"]?>' value='<?php echo $row["NAME"]?>'></option>
              <?php 
          }?>
      </datalist>

      <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
      </div>
      <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
      <!--<p>Arvin Garcia</p> -->
      <br>
      <p><?php echo $res_Uname ?></p>


      <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>



    
    <!-- end -->

    <!-- Banner part of the page -->
    <div class="grid2">
        <h1>NEW YEAR SALE</h1>
        <h3>JAN 1 - JAN 24</h3>
    </div>
    <img class="overlay-image" src="../images/car.png" alt="Your image description">
    <img class="overlay-image2" src="../images/car.png" alt="Your image description">
    <!-- end -->

    <!-- Top selling items part of the page -->
    <div class="grid3">
      <h3>Product List</h3>

      <div class="vertical-media-scroller">


        <?php
        error_reporting(E_ALL ^ E_WARNING);
        if ($_POST['accessoryType'] != NULL OR $_POST['priceRange'] != NULL ) {
          while($row = mysqli_fetch_assoc($all_product)){
            if ($_POST['accessoryType'] != NULL AND $_POST['priceRange'] != NULL)  {
              if ($_POST['priceRange'] == 'air_purifier') {
              if ($row["PRICE"] >=0 AND $row["PRICE"] <= 5000){
                if ($row["Category"] == $_POST['accessoryType'] ){
                ?>
                <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                  <div class="item-gray-bg">
                    <div class="item-white-bg">
                      <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                    </div>
                    <div class="item-details">
                      <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                      <div class="price-container">
                        <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                        <div class="price-sold"><p>1,064 sold</p></div>  
                      </div>
                    </div>
                  </div>
                </div> <!-- end -->
                <?php 
            }}} else if ($_POST['priceRange'] == 'car_vacuum'){
              if ($row["PRICE"] >=5000 AND $row["PRICE"] <= 10000){
                if ($row["Category"] == $_POST['accessoryType'] ){
              ?>
              <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                    <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-sold"><p>1,064 sold</p></div>  
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
              }}} else if ($_POST['priceRange'] == 'engine_oil'){
                if ($row["PRICE"] >=10000 AND $row["PRICE"] <= 15000){
                  if ($row["Category"] == $_POST['accessoryType'] ){
                ?>
                <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                  <div class="item-gray-bg">
                    <div class="item-white-bg">
                      <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                    </div>
                    <div class="item-details">
                      <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                      <div class="price-container">
                        <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                        <div class="price-sold"><p>1,064 sold</p></div>  
                      </div>
                    </div>
                  </div>
                </div> <!-- end -->
                <?php 
            }}} else if ($_POST['priceRange'] == 'air_filter'){
              if ($row["PRICE"] >=15000 AND $row["PRICE"] <= 20000){
                if ($row["Category"] == $_POST['accessoryType'] ){
              ?>
              <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                    <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-sold"><p>1,064 sold</p></div>  
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
          }}}else if ($_POST['priceRange'] == 'pressure_washer'){
            if ($row["PRICE"] >= 20000){
              if ($row["Category"] == $_POST['accessoryType'] ){
            ?>
            <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
              <div class="item-gray-bg">
                <div class="item-white-bg">
                  <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                </div>
                <div class="item-details">
                  <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                  <div class="price-container">
                    <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                    <div class="price-sold"><p>1,064 sold</p></div>  
                  </div>
                </div>
              </div>
            </div> <!-- end -->
            <?php 
        }}}
            } else if ($_POST['accessoryType'] != NULL) {
              if ($row["Category"] == $_POST['accessoryType'] ){
                ?>
                <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                  <div class="item-gray-bg">
                    <div class="item-white-bg">
                      <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                    </div>
                    <div class="item-details">
                      <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                      <div class="price-container">
                        <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                        <div class="price-sold"><p>1,064 sold</p></div>  
                      </div>
                    </div>
                  </div>
                </div> <!-- end -->
                <?php 
                    }
            } else if ($_POST['priceRange'] != NULL) {
              if ($_POST['priceRange'] == 'air_purifier'){
                if ($row["PRICE"] >=0 AND $row["PRICE"] <= 5000){
                ?>
                <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                  <div class="item-gray-bg">
                    <div class="item-white-bg">
                      <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                    </div>
                    <div class="item-details">
                      <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                      <div class="price-container">
                        <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                        <div class="price-sold"><p>1,064 sold</p></div>  
                      </div>
                    </div>
                  </div>
                </div> <!-- end -->
                <?php 
            }} else if ($_POST['priceRange'] == 'car_vacuum'){
              if ($row["PRICE"] >=5000 AND $row["PRICE"] <= 10000){
              ?>
              <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                    <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-sold"><p>1,064 sold</p></div>  
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
              }} else if ($_POST['priceRange'] == 'engine_oil'){
                if ($row["PRICE"] >=10000 AND $row["PRICE"] <= 15000){
                ?>
                <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                  <div class="item-gray-bg">
                    <div class="item-white-bg">
                      <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                    </div>
                    <div class="item-details">
                      <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                      <div class="price-container">
                        <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                        <div class="price-sold"><p>1,064 sold</p></div>  
                      </div>
                    </div>
                  </div>
                </div> <!-- end -->
                <?php 
            }} else if ($_POST['priceRange'] == 'air_filter'){
              if ($row["PRICE"] >=15000 AND $row["PRICE"] <= 20000){
              ?>
              <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                    <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-sold"><p>1,064 sold</p></div>  
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
          }} else if ($_POST['priceRange'] == 'pressure_washer'){
            if ($row["PRICE"] >= 20000){
            ?>
            <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
              <div class="item-gray-bg">
                <div class="item-white-bg">
                  <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                </div>
                <div class="item-details">
                  <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                  <div class="price-container">
                    <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                    <div class="price-sold"><p>1,064 sold</p></div>  
                  </div>
                </div>
              </div>
            </div> <!-- end -->
            <?php 
        }}}
      }?>
          <?php
          }else {
              while($row = mysqli_fetch_assoc($all_product)){
              ?>
              <div class="media-item" onclick="window.location.href = '../html/product2.php?prodid='+<?php echo $row["PRODUCT_ID"]; ?>;"> <!-- Entire product container -->
                <div class="item-gray-bg">
                  <div class="item-white-bg">
                    <img src="../images/<?php echo $row["image"]  ?>" alt="cart icon" style="height: 100px; width: 120px">
                  </div>
                  <div class="item-details">
                  <h5><?php echo $row["NAME"]  ?><?php if ($row["STOCK"] <= 0 ){ ?><a style="color: red">Out of Stock</a><?php } ?></h5>
                    <div class="price-container">
                      <div class="price-disc"><p>P<?php echo $row["PRICE"]  ?></p></div>
                      <div class="price-sold"><p>1,064 sold</p></div>  
                    </div>
                  </div>
                </div>
              </div> <!-- end -->
              <?php 
                  }}
        ?>
        </div>
    </div>
    <!-- end -->

    <!-- Filter part of the page -->
    <div class="grid4" id="products">
      <h3>Filter</h3>
      <form name="category" action="" method="post">
      
      <select id="accessoryType" style="border-radius: 6px; padding-left: 2px;" name="accessoryType">
        <option value="">Select Accessory</option>
        <optgroup label="Interior">
          <option value="floor_mats">Floor Mats</option>
          <option value="seat_covers">Seat Covers</option>
          <option value="sunshades">Sunshades</option>
          <option value="organizers">Organizers</option>
          <option value="phone_mounts">Phone Mounts</option>
        </optgroup>
        <optgroup label="Exterior">
          <option value="car_covers">Car Covers</option>
          <option value="windshield_sunshades">Windshield Sunshades</option>
          <option value="mud_flaps">Mud Flaps</option>
          <option value="roof_racks">Roof Racks</option>
          <option value="bike_racks">Bike Racks</option>
        </optgroup>
        <optgroup label="Performance">
          <option value="air_suspension_kit">Air Suspension Kit</option>
          <option value="coil_spring">Coil Spring</option>
          <option value="polyurethane_bushing">Polyurethane Bushing</option>
          <option value="wheel_spacer">Wheel Spacer</option>
          <option value="sway_bar">Sway Bar</option>
        </optgroup>
        <optgroup label="Safety">
          <option value="dash_cam">Dash Cam</option>
          <option value="car_alarm">Car Alarm</option>
          <option value="side_mirror">Side Mirror</option>
          <option value="parking_sensor">Parking Sensor</option>
          <option value="wheel_lock">Wheel Lock</option>
        </optgroup>
        <optgroup label="Cleaning and Maintenance">
          <option value="air_purifier">Air Purifier</option>
          <option value="car_vacuum">Car Vacuum</option>
          <option value="engine_oil">Engine Oil</option>
          <option value="air_filter">Air Filter</option>
          <option value="pressure_washer">Pressure Washer</option>
        </optgroup>
        <optgroup label="Miscellaneous">
          <option value="keychain">Keychain</option>
          <option value="phone_charger">Phone Charger</option>
          <option value="cup_holder">Cup Holder</option>
          <option value="car_fragrance">Car Fragrances</option>
          <option value="travel_pillow">Travel Pillow</option>
        </optgroup>
      </select>
        
      <select id="priceRange" style="border-radius: 6px; padding-left: 2px;" name="priceRange">
        <option value="">Select Price Range</option>
        <option value="air_purifier">PHP 0 - PHP 5,000</option>
        <option value="car_vacuum">PHP 5,000 - PHP 10,000</option>
        <option value="engine_oil">PHP 10,000 - PHP 15,000</option>
        <option value="air_filter">PHP 15,000 - PHP 20,000</option>
        <option value="pressure_washer">PHP 20,000+</option>
        </select>
      
      <br><br>

      <input type="submit" name="Search" class="submit" value="Search">
      </form>
    </div>
    <!-- end -->

    <!-- Top selling products part of the page -->
    <div class="grid5">
      <h3>Top Selling Items</h3>

      <div class="media-scroller">
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/air-filter.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Air Filter</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 399.00</p></div>
                <div class="price-sold"><p>34 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/armrest-console-box.jpg" alt="cart icon" style="width: 75px; padding-top: 10px;">
            </div>
            <div class="item-details">
              <h5>Armrest Console Box</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 1,499.00</p></div>
                <div class="price-sold"><p>17 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/hood-scoop.jpg" alt="cart icon" style="width: 100px">
            </div>

            </div>
          </div>
        </div>
        </div>
    </div>
    <!-- end -->

    <!-- Latest products part of the page -->
    <div class="grid6">
      <h3>Latest Products</h3>

      <div class="media-scroller">
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/air-filter.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Air Filter</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 399.00</p></div>
                <div class="price-sold"><p>34 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/armrest-console-box.jpg" alt="cart icon" style="width: 75px; padding-top: 10px;">
            </div>
            <div class="item-details">
              <h5>Armrest Console Box</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 1,499.00</p></div>
                <div class="price-sold"><p>17 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/hood-scoop.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Hood Scoop</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 749.00</p></div>
                <div class="price-sold"><p>29 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/side-mirror.jpg" alt="cart icon" style="width: 90px">
            </div>
            <div class="item-details">
              <h5>Side Mirror</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 149.00</p></div>
                <div class="price-sold"><p>36 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/roll-bar.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Roll Bar</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 18,500.00</p></div>
                <div class="price-sold"><p>16 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        </div>
    </div>
    <!-- end -->
  </div> <!-- end of wrapper div -->

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>

</body>

</html>
