<?php 
    session_start();
    include("connect.php");
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Media</title>

    <link rel="stylesheet" href="../css/styles-social-media.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->

  <?php
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }
?>


    <!-- Top part of the page -->
    <div class="grid1">
        <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Auto Master Online</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
        </div>
        <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
        <p><?php echo $res_Uname ?></p>
        <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
          <option value=""></option>
          
          <option value="Logout.php" > <a>Log Out</a></option>
        </select>
    </div>
    <!-- end -->
    <div class="grid2">
      <div class="container-header">
        <h1>Social Links</h1> 
        <div class="message">
          <p>Want to be updated on our latest promos and deals? Follow us on our social media links so you can stay up to date!</p>
        </div>
      </div>

      <div class="container-supports">
        <div class="box" onclick="window.location = 'https://www.facebook.com/'">
          <img src="../images/social-links/facebook.png">  
          <p>Stay updated through our Facebook page.</p>        
        </div>
        <div class="box" onclick="window.location = 'https://www.instagram.com/' ">
          <img src="../images/social-links/instagram.webp">  
          <p>See our latest deals in our Instagram.</p> 
        </div>
        <div class="box" onclick="window.location = 'https://twitter.com/home?lang=en' ">
          <img src="../images/social-links/x.webp">  
          <p>View our Twitter to see the newest deals.</p> 
        </div>
      </div>
    </div>
  </div>

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>
</body>

</html>
