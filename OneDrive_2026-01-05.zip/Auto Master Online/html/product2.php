<?php 
    session_start();

    include("connect.php");
     
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");
  $prodID = $_GET['prodid'];
  $sql = "SELECT * FROM product WHERE PRODUCT_ID = $prodID";

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }

  if(isset($_POST['submit'])){
    $quantity = $_POST['stockMinusPlus'];
    $checkCart = mysqli_query($con, "SELECT * FROM cart WHERE PRODUCT_ID = '$prodID' AND USER_ID= '$ID'") or die("Select Error");
        if (mysqli_num_rows($checkCart) >= 1){
          echo "<script> alert('Product is already in the cart')</script>";
          header("Refresh:0");
        }else{
          mysqli_query($con, "INSERT INTO cart(PRODUCT_ID,USER_ID,quantity) VALUES('$prodID','$ID','$quantity')") or die ("Error Occured");
          echo "<script> alert('Product successfully added')</script>";
          header("Refresh:0");
          
        }

    

  }else{


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>

    <link rel="stylesheet" href="../css/styles-product.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->
    <!-- Top part of the page -->
    <div class="grid1">
        <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Auto Master Online</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
        </div>
        <img src="../images/cart.jpg" alt="cart icon" style="margin-right:-12px; width: 25px; height: 25px">
        <img src="../images/bell.jpg" alt="bell icon" style="margin-left: 16px; width: 19px; height: 19px">
        <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
        <p><?php echo $res_Uname ?></p>
        <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>
    <!-- end -->
    <div class="grid2">

    <?php
           
           $product = mysqli_query($con, $sql);
          $row = mysqli_fetch_assoc($product);


        ?>
    <form action="" method="post">
      <div class="container-whole">
        <img src="../images/icon-back.jpg" alt="back icon" class="back-icon" onclick="window.location.href = '../html/main-customer.php';">
        <h1><?php echo $row["NAME"]  ?></h1>
        <div class="container-big">
          <div class="container-img">
            <img src="../images/<?php echo $row["image"]  ?>" alt="<?php echo $row["NAME"]  ?>">
          </div>
          <div class="container-info">
            <div class="container-desc">
              <p>
              <?php echo $row["Description"]  ?>
                
              </p>
            </div>
            <!-- <div class="color">
              <div class="container-text-color">
                <p>Color:</p>
              </div>
              <div class="container-colors">
                <div class="white"></div>
                <div class="black"></div>
              </div>
            </div> -->
            <div class="container-quantity">
              <div class="container-text-quantity">
                <p>Quantity:</p>
              </div>
             
              <input type="number" name="stockMinusPlus" id="stockMinusPlus">
              <!--<div class="quantity-changer">
                <div class="quantity">
                  <span class="minus">-</span>
                  <span class="count">1</span>
                  <span class="plus">+ </span>
                </div>
              </div>-->
            </div>
            <button type="submit" name = "submit"  >Add to Cart</button>
          </div>
        </div>
        <div class="price-and-sold">
          <p class="price">PHP<?php echo $row["PRICE"]  ?></p>
          <p class="sold">1,005 sold</p>
        </div>
      </div>
</form>
      <?php 
          
        ?>

    </div>


  </div>





    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>
    <script src="../javascript/script-quantity.js"></script>
    <?php } ?>
</body>

</html>
