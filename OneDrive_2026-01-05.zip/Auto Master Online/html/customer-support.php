<?php
  session_start();

  include("connect.php");
  

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Support</title>

    <link rel="stylesheet" href="../css/styles-customer-support.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->


  <!-- PHP Portion -->
  <?php 
  
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }
  
  

  
  
  ?>


    <!-- Top part of the page -->
    <div class="grid1">
        <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
        <p>Auto Master Online</p>
        <input type="text" class="search-bar" placeholder="Search">
        <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
        </div>
        <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
        <br>
        <p><?php echo $res_Uname ?></p>
        <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>
    <!-- end -->
    <div class="grid2">
      <div class="container-supports">
        <div class="box">
            <h5>Message Support</h5>
            <p>Our support team is just one chat away.</p>
            <p class="line-animation">http://m.me/automasteronline</p>
        </div>
        <div class="box">
          <h5>Email Support</h5>
          <p>Send us an email and we’ll reply quickly.</p>
          <p class="line-animation">automasteronline@gmail.com</p>
        </div>
        <div class="box">
          <h5>Call & Text Support</h5>
          <p>Call or text us through these numbers.</p>
          <p class="line-animation">09123456789</p>
          <p class="line-animation">09112234455</p>
        </div>
      </div>
      <div class="container-support-team">
        <h1>Support Team</h1> 
        <div class="support-message">
          <p>We deeply value how important great customer support is. Our support team knows that choosing the right car accessories can be difficult, and we are here to help you every step of the way.</p>
        </div>
      </div>
      <div class="container-people">
        <div class="person">
            <img src="../images/people/p1.jpg">
            <h3>Elise</h3>
            <p>elise112@gmail.com</p>
        </div>
        <div class="person">
            <img src="../images/people/p3.jpg">
            <h3>Kate</h3>
            <p>katedagreat@gmail.com</p>
        </div>
        <div class="person">
          <img src="../images/people/p2.jpg">
          <h3>Rodie</h3>
          <p>rodie9090@gmail.com</p>
        </div>
        <div class="person">
          <img src="../images/people/p4.jpg">
          <h3>Sam</h3>
          <p>sambautista@gmail.com</p>
        </div>
      </div>
    </div>
  </div>

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>
</body>

</html>
