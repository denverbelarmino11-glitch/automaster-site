<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Master Online</title>
    <link rel="icon" href="../images/logo.jpg">

    <link rel="stylesheet" href="../css/styles-signup.css">
	<link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Barlow and Inter) -->
	<link href='https://fonts.googleapis.com/css?family=Barlow' rel='stylesheet'>
	
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->

    <!-- Php portion -->

    <?php

    include("connect.php");
    if(isset($_POST['submit'])){
      $username = $_POST['Username'];
     

      $password = $_POST['PasswordE'];
    

    // verifying the unique username
    $verify_query = mysqli_query($con, "SELECT USERNAME FROM users WHERE USERNAME='$username'");

    if (mysqli_num_rows($verify_query) !=0){
        echo "<div class = 'message'>
                  <p>This email is taken. Try another one please.</p>
                  </div> <br>";
        echo "<a href ='javascript:self.history.back()'><button class= 'btn'>Go Back</button>";

    }else{
     
      mysqli_query($con, "INSERT INTO users(Password,USERNAME) VALUES('$password','$username')") or die ("Error Occured");

      echo "<div class = 'message'>
              <p>Registration Successful</p>
              </div> <br>";
      echo "<a href ='login.php'><button class= 'btn'>Login Now</button>";

      
    }
    

  }else{

    
    ?>




    <!-- Top part of the page -->
    <div class="grid1">
      <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
      <p>Auto Master Online</p>
      <input type="text" class="search-bar" placeholder="Search">
      <div class="others-container">
        <p class="others" onclick="location.href = 'main-customer.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>

        
      </div>
    </div>
    <!-- end -->
	
	<!-- Login Page Start -->
	<div class="grid2">
		<img src="../images/logonobg2.png" class="login-logo" alt="AMO logo" style="float: center;">
		<center>
		<form class="login-form" action="" method="post">

    <!--
			<input type="text" class="login-input" placeholder="Email">
      <input type="password" class="login-input" placeholder="Password" style="margin-bottom: 2px;">
  -->

      <input type="text" class="login-input" placeholder="Username" name ="Username" id = "Username" autocomplete = "off" required>
     
      <input type="password" class="login-input" placeholder="Password" name ="PasswordE" id = "PasswordE" autocomplete = "off" required>


      <div class="field input"> 
        
      <input type="submit" class="btn" name = "submit" value="Sign Up">
      </div>
      <p> Already a member?</p>
      <div class="links">
       <a class="btn" href="login.php">Sign In</a>
     
    
      </div>
			</center>
     


    </form>
		<br>
		<!--<a href="/html/login.html"><button class="login-button" style="margin-top: 25px; margin-bottom: 5px;">Sign Up</button></a> -->
    <br>
		<br>
		<br>
    </div>
	<!-- end -->

  </div> <!-- end of wrapper div -->

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>

    <?php } ?>

</body>

</html>
