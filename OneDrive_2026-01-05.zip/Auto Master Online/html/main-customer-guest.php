

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <link rel="stylesheet" href="../css/styles-customer.css">
    <link rel="icon" href="../images/logo.jpg">

    <!-- Custom fonts used (Krona One and Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
  </head>

<body>
  <div class="wrapper"> <!-- Wraps the whole page -->

  <!-- PHP Portion -->
  

    <!-- Top part of the page -->
    <div class="grid1">
      <img src="../images/logo.jpg" alt="AMO logo" style="float: left;">
      <p>Auto Master Online</p>
      <input type="text" class="search-bar" placeholder="Search">
      <div class="others-container">
      <p class="others" onclick="location.href = 'main-customer-guest.php';">Home</p>
        <p class="others" onclick="location.href = 'customer-support.php';">Customer Support</p>
        <p class="others" onclick="location.href = 'social-media.php';">Social Media</p>
        <p class="others" onclick="location.href = 'about-us.php';">About Us</p>
        <p class="others" onclick="location.href = 'cart.php';">Cart</p>
      </div>
      <img src="../images/profile.jpg" alt="profile icon" style="float: left;">
      <p>Guest</p>
      


      
      <select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer; z-index: 10">
        <option value=""></option>
        
        <option value="Logout.php" > <a>Log Out</a></option>
      </select>
    </div>



    
    <!-- end -->

    <!-- Banner part of the page -->
    <div class="grid2">
        <h1>NEW YEAR SALE</h1>
        <h3>JAN 1 - JAN 24</h3>
    </div>
    <img class="overlay-image" src="../images/car.png" alt="Your image description">
    <img class="overlay-image2" src="../images/car.png" alt="Your image description">
    <!-- end -->

    <!-- Top selling items part of the page -->
    <div class="grid3">
      <h3>Product List</h3>

      <div class="vertical-media-scroller">

        <div class="media-item" onclick="window.location.href = '../html/product1.html';"> <!-- Entire product container -->
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/spoiler-ducktail.webp" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Spoiler</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 799.00</p></div>
                <div class="price-sold"><p>1,064 sold</p></div>  
              </div>
            </div>
          </div>
        </div> <!-- end -->

        </div>
    </div>
    <!-- end -->

    <!-- Filter part of the page -->
    <div class="grid4">
      <h3>Filter</h3>
      
      <select id="accessoryType" style="border-radius: 6px; padding-left: 2px;">
        <option value="">Select Accessory</option>
        <optgroup label="Interior">
          <option value="floor_mats">Floor Mats</option>
          <option value="seat_covers">Seat Covers</option>
          <option value="sunshades">Sunshades</option>
          <option value="organizers">Organizers</option>
          <option value="phone_mounts">Phone Mounts</option>
        </optgroup>
        <optgroup label="Exterior">
          <option value="car_covers">Car Covers</option>
          <option value="windshield_sunshades">Windshield Sunshades</option>
          <option value="mud_flaps">Mud Flaps</option>
          <option value="roof_racks">Roof Racks</option>
          <option value="bike_racks">Bike Racks</option>
        </optgroup>
        <optgroup label="Performance">
          <option value="air_suspension_kit">Air Suspension Kit</option>
          <option value="coil_spring">Coil Spring</option>
          <option value="polyurethane_bushing">Polyurethane Bushing</option>
          <option value="wheel_spacer">Wheel Spacer</option>
          <option value="sway_bar">Sway Bar</option>
        </optgroup>
        <optgroup label="Safety">
          <option value="dash_cam">Dash Cam</option>
          <option value="car_alarm">Car Alarm</option>
          <option value="side_mirror">Side Mirror</option>
          <option value="parking_sensor">Parking Sensor</option>
          <option value="wheel_lock">Wheel Lock</option>
        </optgroup>
        <optgroup label="Cleaning and Maintenance">
          <option value="air_purifier">Air Purifier</option>
          <option value="car_vacuum">Car Vacuum</option>
          <option value="engine_oil">Engine Oil</option>
          <option value="air_filter">Air Filter</option>
          <option value="pressure_washer">Pressure Washer</option>
        </optgroup>
        <optgroup label="Miscellaneous">
          <option value="keychain">Keychain</option>
          <option value="phone_charger">Phone Charger</option>
          <option value="cup_holder">Cup Holder</option>
          <option value="car_fragrance">Car Fragrances</option>
          <option value="travel_pillow">Travel Pillow</option>
        </optgroup>
      </select>

      <select id="priceRange" style="border-radius: 6px; padding-left: 2px;">
        <option value="">Select Price Range</option>
        <option value="air_purifier">PHP 0 - PHP 5,000</option>
        <option value="car_vacuum">PHP 5,000 - PHP 10,000</option>
        <option value="engine_oil">PHP 10,000 - PHP 15,000</option>
        <option value="air_filter">PHP 15,000 - PHP 20,000</option>
        <option value="pressure_washer">PHP 20,000+</option>
        </select>
      
      <br><br>

      <button type="button">Search</button>
    </div>
    <!-- end -->

    <!-- Top selling products part of the page -->
    <div class="grid5">
      <h3>Top Selling Items</h3>

      <div class="media-scroller">
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/air-filter.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Air Filter</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 399.00</p></div>
                <div class="price-sold"><p>34 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/armrest-console-box.jpg" alt="cart icon" style="width: 75px; padding-top: 10px;">
            </div>
            <div class="item-details">
              <h5>Armrest Console Box</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 1,499.00</p></div>
                <div class="price-sold"><p>17 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/hood-scoop.jpg" alt="cart icon" style="width: 100px">
            </div>

            </div>
          </div>
        </div>
        </div>
    </div>
    <!-- end -->

    <!-- Latest products part of the page -->
    <div class="grid6">
      <h3>Latest Products</h3>

      <div class="media-scroller">
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/air-filter.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Air Filter</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 399.00</p></div>
                <div class="price-sold"><p>34 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/armrest-console-box.jpg" alt="cart icon" style="width: 75px; padding-top: 10px;">
            </div>
            <div class="item-details">
              <h5>Armrest Console Box</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 1,499.00</p></div>
                <div class="price-sold"><p>17 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/hood-scoop.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Hood Scoop</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 749.00</p></div>
                <div class="price-sold"><p>29 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/side-mirror.jpg" alt="cart icon" style="width: 90px">
            </div>
            <div class="item-details">
              <h5>Side Mirror</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 149.00</p></div>
                <div class="price-sold"><p>36 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        <div class="media-item">
          <div class="item-gray-bg">
            <div class="item-white-bg">
              <img src="../item-images/roll-bar.jpg" alt="cart icon" style="width: 100px">
            </div>
            <div class="item-details">
              <h5>Roll Bar</h5>
              <div class="price-container">
                <div class="price-disc"><p>P 18,500.00</p></div>
                <div class="price-sold"><p>16 sold</p></div>  
              </div>

            </div>
          </div>
        </div>
        </div>
    </div>
    <!-- end -->
  </div> <!-- end of wrapper div -->

    <!-- Functionalities -->
    <script src="../javascript/script-main-customer.js"></script>

</body>

</html>
