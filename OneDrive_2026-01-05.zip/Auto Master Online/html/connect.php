<?php

$con = mysqli_connect("localhost","root","","masters_db") or die ("Connection Error");



?>


<!-- 

Things to do

signup.html

login.html


Databases needed to connect here

User Login Connection(login.html) (done)
Product Home Page Connection (done)
Order Cart Connection
Item Stock Connection
Sales Analytics Connection (No Idea how to do)


variables (for login and signup)
Tablename : users
ID (PK)(From Database)
Username
PasswordE
EmailE
pNumber

Variables for Item Stock Connection
add-product.html (Webpage used)

Product_ID (PK)
Name
Price
Stock
prodDescription
prodCategory
priceRange



Variables used for Order Cart Connection
cart.html (Webpage used) (Cannot increase the amount of stock that the website has, can only decrease or stay the same amount))
item-stock.html (Can increase and decrease the amount of stock that the website has, this is the admin side))
Stock_ID PK
Product_ID FK
Stock FK

tables:
1. Cart_Item (For Order Summary)
Cart_Item_ID PK
Cart_ID FK
Product_ID FK
No_product_items
totalPrice (price of all products)



2. Cart
Cart_ID PK
ID FK
Product_ID FK
Quantity
TotalPrice






 -->