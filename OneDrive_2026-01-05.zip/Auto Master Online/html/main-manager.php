<?php 
    session_start();

    include("connect.php");
     
  $ID = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT* FROM users WHERE USER_ID = $ID");

  while($result = mysqli_fetch_assoc($query)){
    $res_Uname = $result['USERNAME'];
   
    $res_ID = $result['USER_ID'];
  }
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Dashboard</title>
		<!-- Fonts used -->
		<link rel="stylesheet" href="../css/styles-manager.css">
		<link rel="icon" href="../images/logo.jpg">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&display=swap" rel="stylesheet">

		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">

		<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


	
</head>
<body>
    <div class="wrapper">
        <div class="grid1">
					<img src="../images/profile.jpg	" alt="profile icon" style="float: left;">
					<p class="profile-name">
					<?php echo $res_Uname ?>
						<span class="small-text">Manager</span>
					</p>
					
					<select id="profile-dropdown" name="form" onchange="location = this.value;" style="width: 20px; border: none; font-family: Inter; font-size: 12px; cursor: pointer;">
						<option value=""></option>
						<option value="logout.php ">Logout</option>
					</select>
				</div>

        <div class="grid2">
          <div class="sidebar">
						<div class="logo-container" style="margin-bottom: -30px;">
								<img src="../images/logo2.jpg" alt="Logo" style="width: 80px; margin-bottom: 6px;">
						</div>
						<ul>
							<li><a href="main-manager.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
							<li><a href="item-stock.php"><i class="fas fa-box-open"></i>Item Stock</a></li>
							<li><a href="add-product.php"><i class="fas fa-box-open"></i>Add Product</a></li>
						</ul>
					</div>
        </div>
		
    <div class="grid3">
			<img src="../images/icon-current-order.jpg" alt="box icon" class="box-icon">
			<p class="current-order">
				<span class="small-text">Current Orders</span>
				<br>
				<span class="big-text">14</span>
			</p>
		</div>
		
        <div class="grid4">
			<img src="../images/icon-orders-in-user-carts.jpg" alt="cart icon" class="box-icon">
				<p class="order-cart">
					<span class="small-text">Orders in Carts</span>
					<br>
					<span class="big-text">14</span>
				</p>
		</div>
		
        <div class="grid5">
			<img src="../images/icon-items-to-be-resupplied.jpg" class="box-icon">
				<p class="resupplied">
					<span class="small-text">Items to be Resupplied</span>
					<br>
				<span class="big-text">59</span>
				</p>
		</div>
		
        <div class="grid6">
			<img src="../images/icon-total-item-stocks.jpg" alt="box3 icon" class="box-icon">
				<p class="total-stocks">
					<span class="small-text">Total Item Stocks</span>
					<br>
					<span class="big-text">277</span>
				</p>
		</div>
		
    <div class="grid7">
			<h3>Top Selling Items</h3>
				<div class="dropdown-month">
					<label id="monthSelectLabel" for="monthSelect">Select Month: </label>
					<select class="month" id="monthSelect" onchange="updateChart()">
						<option value="">All</option>
						<option value="6 months ago">6 months ago</option>
						<option value="5 months ago">5 months ago</option>
						<option value="4 months ago">4 months ago</option>
						<option value="3 months ago">3 months ago</option>
						<option value="2 months ago">2 months ago</option>
						<option value="Last month">Last month</option>
					</select>
				</div>

					<div class="media-scroller">
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/rear-camera.jpg" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Rear Camera</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 518.00</p></div>
										<div class="price-sold"><p>1,005 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/rain-visor.webp" alt="cart icon" style="width: 100px; padding-top:20px">
								</div>
								<div class="item-details">
									<h5>Rain Visor</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 1,399.00</p></div>
										<div class="price-sold"><p>981 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/headlight-cover.webp" alt="cart icon" style="width: 100px; padding-top:20px">
								</div>
								<div class="item-details">
									<h5>Headlight Cover</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 779.00</p></div>
										<div class="price-sold"><p>929 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/auxiliary-light.jpg" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Auxiliary Light</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 2,899.00</p></div>
										<div class="price-sold"><p>854 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/fender-flare.webp" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Fender Flare</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 4,700.00</p></div>
										<div class="price-sold"><p>805 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/fuel-tank-cover.webp" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Fuel Tank Cover</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 615.00</p></div>
										<div class="price-sold"><p>758 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/crossbar.jpg" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Crossbar</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 4,799.00</p></div>
										<div class="price-sold"><p>701 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/seat-cover.jpg" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Seat Cover</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 599.00</p></div>
										<div class="price-sold"><p>604 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
						<div class="media-item">
							<div class="item-gray-bg">
								<div class="item-white-bg">
									<img src="../item-images/diffuser.jpg" alt="cart icon" style="width: 100px">
								</div>
								<div class="item-details">
									<h5>Diffuser</h5>
									<div class="price-container">
										<div class="price-disc"><p>P 149.00</p></div>
										<div class="price-sold"><p>558 sold</p></div>  
									</div>
								</div>
							</div>
						</div> 
							</div>
		</div>
		
        <div class="grid9">
					<h3>Financial Performance</h3>
					<div class="dropdown-month">
						<label id="monthSelectLabel" for="monthSelect">Select Month: </label>
										<select class="month" id="monthSelect" onchange="updateChart()">
											<option value="">All</option>
											<option value="6 months ago">6 months ago</option>
											<option value="5 months ago">5 months ago</option>
											<option value="4 months ago">4 months ago</option>
											<option value="3 months ago">3 months ago</option>
											<option value="2 months ago">2 months ago</option>
											<option value="Last month">Last month</option>
										</select>
					</div>
					<div>
					<script
					src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
					</script>

					<canvas id="Finance" style="width:100%;max-width:600px"></canvas>

					<script>
					var xValues1 = ["Interior", "Exterior", "Performance", "Safety", "Cleaning", "Miscellaneous"];
					var yValues1 = [49, 78, 80, 65, 30, 36];
					var barColors1 = ["red", "green","blue","orange","brown", "yellow"];

					new Chart("Finance", {
					type: "bar",
					data: {
						labels: xValues1,
						datasets: [{
						backgroundColor: barColors1,
						data: yValues1
						}]
					},
					options: {
						legend: {display: false},
						title: {
						display: true,
						text: "Financial Performance"
						}
					}
					});
					</script>

					</div>

        </div>
		
        <div class="grid8">
					<h3>Income</h3>
					<div class="dropdown-month">
						<label id="linechartSelectLabel" for="linechartSelect">Select Month: </label>
							<select class="month" id="linechartSelect" onchange="updateChart()">
								<option value="">All</option>
								<option value="6 months ago">6 months ago</option>
								<option value="5 months ago">5 months ago</option>
								<option value="4 months ago">4 months ago</option>
								<option value="3 months ago">3 months ago</option>
								<option value="2 months ago">2 months ago</option>
								<option value="Last month">Last month</option>
							</select>
					</div>
					<div>
					

					<script
					src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
					</script>

					<canvas id="Income" style="width:100%;max-width:600px"></canvas>

					<script>
					const xValues2 = [50,60,70,80,90,100,110,120,130,140,150];
					const yValues2 = [7,8,8,9,9,9,10,11,14,14,15];

					new Chart("Income", {
					type: "line",
					data: {
						labels: xValues2,
						datasets: [{
						fill: false,
						lineTension: 0,
						backgroundColor: "rgba(0,0,255,1.0)",
						borderColor: "rgba(0,0,255,0.1)",
						data: yValues2
						}]
					},
					options: {
						legend: {display: false},
						scales: {
						yAxes: [{ticks: {min: 6, max:16}}],
						}
					}
					});
					</script>

					</div>

        </div>
		
        <div class="grid10">
					<h3>Expenses</h3>
					<div class="dropdown-month">
						<label id="linechartSelectLabel2" for="linechartSelect2">Select Month: </label>
							<select class="month" id="linechartSelect2" onchange="updateChart()">
								<option value="">All</option>
								<option value="6 months ago">6 months ago</option>
								<option value="5 months ago">5 months ago</option>
								<option value="4 months ago">4 months ago</option>
								<option value="3 months ago">3 months ago</option>
								<option value="2 months ago">2 months ago</option>
								<option value="Last month">Last month</option>
							</select>
							</div>
					<div>
					<script
					src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
					</script>
					
							<canvas id="Expenses" style="width:100%;max-width:600px"></canvas>

							<script>
					const xValues3 = [50,60,70,80,90,100,110,120,130,140,150];
					const yValues3 = [8,7,9,10,7,9,8,12,8,9,10];

					new Chart("Expenses", {
					type: "line",
					data: {
						labels: xValues3,
						datasets: [{
						fill: false,
						lineTension: 0,
						backgroundColor: "rgba(255,0,0,1.0)",
						borderColor: "rgba(255,0,0,0.1)",
						data: yValues3
						}]
					},
					options: {
						legend: {display: false},
						scales: {
						yAxes: [{ticks: {min: 6, max:16}}],
						}
					}
					});
					</script> 
					</div>


        </div>
    </div>

    <script src="../javascript/script-main-manager.js"></script>

</body>
	

</html>
