document.addEventListener("DOMContentLoaded", function() {
    const plus = document.querySelector(".plus"),
          minus = document.querySelector(".minus"),
          count = document.querySelector(".count");

    let a = 1;

    plus.addEventListener("click", () => {
        a++;
        a = (a < 10) ? a : a;
        count.innerText = a;
        console.log(a);
    });

    minus.addEventListener("click", () => {
        if (a > 1) {
            a--;
            a = (a < 10) ? a : a;
            count.innerText = a;
            console.log(a);
        }
    });
});

