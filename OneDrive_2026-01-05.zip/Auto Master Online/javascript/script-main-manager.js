google.charts.load("current", {packages:["corechart", "bar"]});
			google.charts.setOnLoadCallback(drawCharts);

				function drawCharts() {
					drawPieChart();
					drawBarChart();
					drawLineChart();
					drawLineChart2();
				}

				function drawPieChart() {
					var data = google.visualization.arrayToDataTable([
						['Sales chart', 'Sales per Month'],
						['Calapan', 38],
						['San Jose', 6],
						['Banawe', 35],
						['Batangas', 21],
					]);

					var options = {
						title: '',
						titleTextStyle: {
						fontSize: 18,
						bold: true,
						italic: false,
						alignment: 'left',
					},
					pieHole: 0.25,
					is3D: false,
					chartArea: {
                    left: 0,
                    width: 500,
					},
					backgroundColor: 'transparent',
				};

					var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
						chart.draw(data, options);
					}	

				function drawBarChart(selectedMonth) {
					var rawData = [
						['Months', 'Internal', 'External Front', 'External Rear', 'Side'],
						['January', 800, 300, 150, 80],
						['February', 900, 350, 180, 70],
						['March', 700, 250, 120, 60],
						['April', 1100, 450, 220, 50],
						['May', 950, 400, 200, 40],
						['June', 1200, 500, 250, 30],
					];

					var data = google.visualization.arrayToDataTable(rawData);

						if (selectedMonth) {
							var rowIndex = -1;
								for (var i = 1; i < rawData.length; i++) {
									if (rawData[i][0] === selectedMonth) {
										rowIndex = i;
										break;
									}
								}

						if (rowIndex !== -1) {
							data = new google.visualization.DataTable();
							data.addColumn('string', 'Category');
								for (var j = 1; j < rawData[0].length; j++) {
									data.addColumn('number', rawData[0][j]);
									}
							data.addRow(rawData[rowIndex].slice(0, rawData[0].length));

                    var options = {
                        chart: {
                            title: '',
                            subtitle: 'Sales, Expenses, and Profit for ' + selectedMonth,
                        }
                    };

                    var chart = new google.charts.Bar(document.getElementById('columnchart'));
                    chart.draw(data, google.charts.Bar.convertOptions(options));
                    return;
                }
            }

					var options = {
						chart: {
						title: '',
						titleTextStyle: {
							fontSize: 18,
							bold: true,
							italic: false,
							alignment: 'left',
						}
					}
				};

					var chart = new google.charts.Bar(document.getElementById('columnchart'));
					chart.draw(data, google.charts.Bar.convertOptions(options));
					}
		
				function drawLineChart(selectedMonth) {
					var rawData = [
						['Months', 'Sales'],
						['January', 800,],
						['February', 900,],
						['March', 700,],
						['April', 1100,],
						['May', 950,],
						['June', 1200,],
					];

					var data = google.visualization.arrayToDataTable(rawData);

					if (selectedMonth) {
							var rowIndex = -1;
								for (var i = 1; i < rawData.length; i++) {
									if (rawData[i][0] === selectedMonth) {
									rowIndex = i;
									break;
								}
							}

						if (rowIndex !== -1) {
							data = new google.visualization.DataTable();
							data.addColumn('string', 'Category');
								for (var j = 1; j < rawData[0].length; j++) {
								data.addColumn('number', rawData[0][j]);
								}
							data.addRow(rawData[rowIndex].slice(0, rawData[0].length));

							var options = {
								title: '',
								subtitle: 'Sales, Expenses, and Profit for ' + selectedMonth,
								curveType: 'function',
							};

							var chart = new google.visualization.LineChart(document.getElementById('linechart'));
							chart.draw(data, options);
							return;
						}
					}

							var options = {
								title: '',
								titleTextStyle: {
								fontSize: 18,
								bold: true,
								italic: false,
								alignment: 'left',
							},
								curveType: 'function',
						};

							var chart = new google.visualization.LineChart(document.getElementById('linechart'));
							chart.draw(data, options);
				}

				function drawLineChart2(selectedMonth) {
					var rawData = [
						['Months', 'Expenses'],
						['January', 200,],
						['February', 100,],
						['March', 300,],
						['April', 1000,],
						['May', 1060,],
						['June', 1200,],
					];

					var data = google.visualization.arrayToDataTable(rawData);

						if (selectedMonth) {
							var rowIndex = -1;
								for (var i = 1; i < rawData.length; i++) {
						if (rawData[i][0] === selectedMonth) {
							rowIndex = i;
							break;
						}
					}

					if (rowIndex !== -1) {
						data = new google.visualization.DataTable();
						data.addColumn('string', 'Category');
							for (var j = 1; j < rawData[0].length; j++) {
                        data.addColumn('number', rawData[0][j]);
						}	
						data.addRow(rawData[rowIndex].slice(0, rawData[0].length));

						var options = {
							title: '',
							subtitle: 'Sales, Expenses, and Profit for ' + selectedMonth,
							curveType: 'function',
						};
	
						var chart = new google.visualization.LineChart(document.getElementById('linechart2'));
							chart.draw(data, options);
							return;
						}
					}

						var options = {
							title: '',
							titleTextStyle: {
							fontSize: 18,
							bold: true,
							italic: false,
							alignment: 'left',
						},
							curveType: 'function',
					};

						var chart = new google.visualization.LineChart(document.getElementById('linechart2'));
						chart.draw(data, options);
				}

					function updateChart() {
						var selectedMonth = document.getElementById('monthSelect').value;
						drawLineChart(selectedMonth);
						drawLineChart2(selectedMonth);
					}


function showDropdown() {
	document.getElementById("dropdown-content").classList.toggle("show");
}

window.onload = function() {
  var body = document.body;

  // Delay opacity change for 3 seconds:
  setTimeout(function() {
    body.style.opacity = 1;
  }, 600); // Adjust timeout to 3 seconds
};

const selectImage = document.querySelector('.select-image');
const inputFile = document.querySelector('#file');
const imgArea = document.querySelector('.img-area');

selectImage.addEventListener('click', function () {
	inputFile.click();
})

inputFile.addEventListener('change', function () {
	const image = this.files[0]
	if(image.size < 2000000) {
		const reader = new FileReader();
		reader.onload = ()=> {
			const allImg = imgArea.querySelectorAll('img');
			allImg.forEach(item=> item.remove());
			const imgUrl = reader.result;
			const img = document.createElement('img');
			img.src = imgUrl;
			imgArea.appendChild(img);
			imgArea.classList.add('active');
			imgArea.dataset.img = image.name;
		}
		reader.readAsDataURL(image);
	} else {
		alert("Image size more than 2MB");
	}
})

