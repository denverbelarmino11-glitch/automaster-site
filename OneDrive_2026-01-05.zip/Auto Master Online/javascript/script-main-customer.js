const searchBar = document.querySelector('.search-bar');

searchBar.addEventListener('keyup', function(event) {
  const searchTerm = event.target.value;
  // Process search term here, e.g., send to server or filter local data
});

window.onload = function() {
  var body = document.body;

  // Delay opacity change for 3 seconds:
  setTimeout(function() {
    body.style.opacity = 1;
  }, 600); // Adjust timeout to 3 seconds
};