-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2024 at 06:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amo`
--

-- --------------------------------------------------------

--
-- Table structure for table `carttable`
--

CREATE TABLE `carttable` (
  `Cart_ID` int(11) NOT NULL,
  `Quantity_Of_All_Items` bigint(20) NOT NULL,
  `totalPrice_Of_All_Items` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carttable`
--

INSERT INTO `carttable` (`Cart_ID`, `Quantity_Of_All_Items`, `totalPrice_Of_All_Items`) VALUES
(10, 0, 0),
(11, 0, 0),
(12, 0, 0),
(13, 0, 0),
(14, 0, 0),
(15, 0, 0),
(16, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `Product_ID` int(11) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Price` bigint(20) NOT NULL,
  `Stock` bigint(20) NOT NULL,
  `prodDescription` varchar(500) NOT NULL,
  `prodCategory` varchar(200) NOT NULL,
  `priceRange` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`Product_ID`, `PName`, `Price`, `Stock`, `prodDescription`, `prodCategory`, `priceRange`) VALUES
(1, 'bumper', 5500, 353, '', 'floor_mats', 'air_purifier'),
(2, 'car', 99999, 87, 'car', 'air_suspension_kit', 'air_purifier'),
(3, 'Nimbus3000', 50000, 2, 'broomstick ni harry', 'air_suspension_kit', 'pressure_washer'),
(4, 'batmobile', 9000000, 0, 'galing sa kweba ni superman', 'bike_racks', 'pressure_washer'),
(5, 'product', 1000, 498, 'asd', 'seat_covers', 'car_vacuum');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `PasswordE` varchar(100) NOT NULL,
  `EmailE` varchar(100) NOT NULL,
  `pNumber` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Username`, `PasswordE`, `EmailE`, `pNumber`) VALUES
(3, 'voldemort', 'voldy', 'voldemort@hogwarts.edu.ph', 9192121502),
(4, 'ang sarap ng tubig', 'tubig', 'absolutevalue@mapua.edu.ph', 5002),
(5, 'adriel', 'pgoiakosobra', 'adriel@yahoo.com', 9231),
(6, 'Adriel Samonte', 'password', 'adrielsamonte@gmail.com', 911);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carttable`
--
ALTER TABLE `carttable`
  ADD PRIMARY KEY (`Cart_ID`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`Product_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carttable`
--
ALTER TABLE `carttable`
  MODIFY `Cart_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
